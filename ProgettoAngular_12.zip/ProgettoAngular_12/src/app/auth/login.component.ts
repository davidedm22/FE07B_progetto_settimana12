import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';

@Component({
  template: `
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="card">
            <div class="text-center">
              <h1>Login</h1>
              <h6>Please enter email e password</h6>
            </div>

            <form #form="ngForm" (ngSubmit)="accedi(form)" >
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label"
                  >Email address</label
                >
                <input
                  type="email"
                  class="form-control"
                  id="email"
                  required

                />
                <div id="emailHelp" class="form-text">
                  We'll never share your email with anyone else.
                </div>
              </div>
              <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label"
                  >Password</label
                >
                <input
                  type="password"
                  class="form-control"
                  id="exampleInputPassword1"
                />
              </div>
              <button type="submit" [disabled]="form.invalid" class="btn btn-primary">Login
              <!-- <span *ngIf="isLoading" class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> -->
              </button>

            </form>
            <a routerLink="/register">New user? clicca per registrarti</a>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class LoginComponent implements OnInit {
  isLoading = false
  constructor(private authSrv:AuthService, private router:Router) {}

  ngOnInit(): void {}

  async accedi(form:NgForm){
    // console.log('login')
    this.isLoading = true
    console.log(form.value);
    try {
      await this.authSrv.login(form.value).toPromise()
      this.isLoading = false
      this.router.navigate(['/movies'])
    } catch (error:any) {
      this.isLoading = false
      form.reset()
      alert(error);
      console.error(error)

    }
  }
}




