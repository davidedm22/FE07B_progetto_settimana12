import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Movie } from '../models/movie';
import { MoviesService } from '../movie.service';

@Component({
  selector: 'app-home',
  template: `
     <div class="container-fluid d-flex text-white text-center">
      <div class="card bg-dark border-white" style="width: 50rem">
        <img
          src=""
          class=" img-thumbnail img-fluid w-100 mx-auto"
          alt="mrRobot"
        />
        <div class="card-body">
          <h1 class="card-title text-info fw-bold">
            Movies<br /><span class="h2"
              >Tutti i tuoi film preferiti sono qui!</span
            >
          </h1>
          <p class="card-text fs-4">
            Accedi subito o registrati gratuitamente per iniziare a guardare
          </p>
          <a
            class="btn btn-primary fs-4 mt-3 w-25"
            [routerLink]="['/login']"
            routerLinkActive="active"
            >Accedi</a
          >
        </div>
      </div>
    </div>
  `,
  styles: [`
  `
  ]
})
export class HomePage implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
