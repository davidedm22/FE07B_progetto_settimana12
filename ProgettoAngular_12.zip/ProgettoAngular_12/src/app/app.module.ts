import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule , Route } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar.component';
import { AuthModule } from './auth/auth.module';
import {HttpClientModule} from "@angular/common/http";
import { FormsModule } from '@angular/forms';
import { MoviesPage } from './pages/movies.component';
import { HomePage } from './pages/homepage.component';
import { ProfilePage } from './pages/profile.component';
import { AuthGuard } from './auth/auth.guard';
import { MovieInfoPage } from './pages/movies-info.component';
import { AuthRoutingModule } from './auth/auth-routing.module';

const routes: Route[] = [
  {
    path: '',
    component: HomePage,
  },
  {
    path: 'movies',
    canActivate: [AuthGuard],
    component: MoviesPage,
    children: [
      {
        path: ':id',
        component: MovieInfoPage,
      },
    ],
  },
  {
    path: 'profile',
    canActivate: [AuthGuard],
    component: ProfilePage,
  },
  {
    path: '**',
    redirectTo: '',
  },
];

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    MoviesPage,
    HomePage,
    ProfilePage,
    MovieInfoPage,
  ],
  imports: [
    BrowserModule,
    AuthModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    AuthRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
